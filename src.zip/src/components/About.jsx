import React from 'react';
import { FaScreenpal, FaUpDown } from 'react-icons/fa6';
import { FaEnvelope, FaMap, FaMapMarkedAlt } from 'react-icons/fa';

const About = () => {
  return (
    <section style={{ padding: '60px 20px', backgroundColor: '#F4F8D4' }}>
      <div style={{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: '60px',
        maxWidth: '1200px',
        margin: '0 auto',
        flexWrap: 'wrap'
      }}>

        {/* LEFT IMAGE */}
        <div style={{ flex: '1 1 40%', position: 'relative', minWidth: '300px' }}>
          <img
            src="/photo-555.avif"
            alt="San Francisco"
            style={{
              width: '100%',
              borderRadius: '30px',
              objectFit: 'cover'
            }}
          />
          <span style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            // backgroundColor: '',
            padding: '6px 14px',
            borderRadius: '20px',
            fontWeight: 600,
            fontSize: '14px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            San Francisco
          </span>
        </div>

        {/* RIGHT TEXT */}
        <div style={{ flex: '1 1 50%', minWidth: '300px' }}>
          <h2 style={{
            fontSize: '42px',
            fontWeight: '800',
            marginBottom: '20px',
            lineHeight: '1.2',
            color: '#000'
          }}>
            Empowering You to Find<br /> Your Dream Home,<br /> Effortlessly
          </h2>

          <p style={{
            fontSize: '16px',
            color: '#6B7280',
            marginBottom: '30px',
            lineHeight: '1.6',
            maxWidth: '500px'
          }}>
            We simplify the journey to your perfect home with expert guidance, verified listings, and tools designed to make every step clear and stress-free.
          </p>


          {/* Feature List */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <FaScreenpal style={{ color: '#4CAF50' }} />
              <span>Virtual property tours and viewings</span>
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <FaUpDown style={{ color: '#4CAF50' }} />
              <span>Real-time market price updates</span>
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <FaMap style={{ color: '#4CAF50' }} />
              <span>Interactive floor plans and maps</span>
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <FaMapMarkedAlt style={{ color: '#4CAF50' }} />
              <span>Access to off-market properties</span>
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <FaEnvelope style={{ color: '#4CAF50' }} />
              <span style={{ backgroundColor: '', padding: '3px 5px', borderRadius: '4px' }}>
                Direct messaging with agents and owners
              </span>
            </div>
          </div>
        </div>

        <div style={{
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '60px 40px',
          borderRadius: '20px',
          gap: '30px'
        }}>
          {/* Text Section */}
          <div style={{ flex: '1 1 500px', minWidth: '300px' }}>
            <h2 style={{
              fontSize: '42px',
              fontWeight: '800',
              marginBottom: '20px',

              lineHeight: '1.2',
              color: '#000'
            }}>
              Simplifying Your Real Estate Journey Every Step of the Way
            </h2>

            <p style={{
              fontSize: '16px',
              color: '#6B7280',
              marginBottom: '30px',
              lineHeight: '1.6',
              maxWidth: '500px'
            }}>
              From property search to closing the deal, we provide the tools, support, and expertise you need to navigate the real estate process with confidence and ease.
            </p>

            {/* Feature List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <FaScreenpal style={{ color: '#4CAF50' }} />
                <span>In-app scheduling for property viewings</span>
              </div>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <FaUpDown style={{ color: '#4CAF50' }} />
                <span>Real-time market price updates</span>
              </div>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <FaMap style={{ color: '#4CAF50' }} />
                <span>User-friendly interface for smooth navigation</span>
              </div>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <FaMapMarkedAlt style={{ color: '#4CAF50' }} />
                <span>Detailed agent and realtor profiles</span>
              </div>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <FaEnvelope style={{ color: '#4CAF50' }} />
                <span>Access to off-market properties</span>
              </div>
            </div>
          </div>

          {/* Image Section */}
          <div style={{
            flex: '1 1 400px',
            borderRadius: '30px',
            overflow: 'hidden',
            boxShadow: '0 10px 80px rgba(0,0,0,0.1)',
            position: 'relative'
          }}>
            <img
              src="/images (12).jpg"
              alt="Golden Coast"
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                borderRadius: '30px'
              }}
            />
            <span style={{
              position: 'absolute',
              top: '20px',
              right: '20px',
              backgroundColor: '#fff',
              padding: '6px 12px',
              borderRadius: '20px',
              fontSize: '14px',
              fontWeight: '500',
              boxShadow: '0 2px 6px rgba(0,0,0,0.1)'
            }}>
              Golden Coast
            </span>
          </div>
        </div>


      </div>
    </section>
  );
};

export default About;
