import React, { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Header from "./Header";
import Footer from "./Footer";

const PropertyDetail = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const dateInputRef = useRef(null);

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        const res = await axios.get(`http://localhost:5500/api/properties/${id}`, { withCredentials: true });
        setProperty(res.data);
      } catch (err) {
        console.error(err);
        setError("Failed to load property details.");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchProperty();
    else {
      setError("Invalid property ID.");
      setLoading(false);
    }
  }, [id]);

  const handleBookVisit = () => setShowBookingForm(true);
  const handleClose = () => setShowBookingForm(false);

  // Dynamically load Razorpay SDK
  const loadRazorpay = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    const form = e.target;

    const bookingData = {
      name: form.name.value,
      email: form.email.value,
      date: form.date.value,
      notes: form.notes.value,
      propertyId: id,
    };

    try {
      // Create booking and get Razorpay order details
      const res = await axios.post("http://localhost:5500/api/bookings", bookingData, { withCredentials: true });
      const { booking, order } = res.data;

      const razorpayLoaded = await loadRazorpay("https://checkout.razorpay.com/v1/checkout.js");
      if (!razorpayLoaded) {
        alert("Razorpay SDK failed to load");
        return;
      }

      const options = {
        key: "rzp_test_INJ02hOhTb9FAT", // Replace with your Razorpay Key ID
        amount: order.amount,
        currency: "INR",
        name: "Dream Home Booking",
        description: `Booking for ${property.title}`,
        order_id: order.id,
        handler: function (response) {
          alert("Payment successful!");
          setShowBookingForm(false);
        },
        prefill: {
          name: bookingData.name,
          email: bookingData.email,
        },
        notes: {
          bookingId: booking._id,
        },
        theme: {
          color: "#000000",
        },
      };

      const paymentObject = new window.Razorpay(options);
      paymentObject.open();
    } catch (err) {
      console.error(err);
      alert("Booking or payment failed.");
    }
  };

  if (loading) return <div>Loading property details...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;
  if (!property) return <div>No property found.</div>;

  const {
    title,
    address,
    location,
    beds,
    baths,
    area,
    rooms,
    price,
    rating,
    details,
    image,
  } = property;

  return (
    <>
      <Header />
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          padding: "20px",
          fontFamily: "Arial",
          marginTop: "100px",
          paddingTop: "80px",
          backgroundColor: "#CBAD7F",
        }}
      >
        <div style={{ flex: 1, minWidth: "320px", marginBottom: "20px" }}>
          <img
            src={image ? `http://localhost:5500${image}` : "/default-image.jpg"}
            alt={title || "Property"}
            style={{
              width: "100%",
              height: "300px",
              objectFit: "cover",
              borderRadius: "10px",
            }}
          />
          <h2>{title}</h2>
          <p style={{ color: "gray" }}>{address}</p>
          <p style={{ color: "green", fontWeight: "bold" }}>{location}</p>
          <p>
            🛏 {beds} &nbsp; 🛁 {baths} &nbsp; 🚗 {area} sqft &nbsp; 🏠 {rooms}{" "}
            Rooms
          </p>
          <h3 style={{ color: "#000" }}>${price.toFixed(2)}</h3>
          <p style={{ color: "green" }}>⭐ {rating}</p>
          <h4>Property Details</h4>
          <p style={{ maxWidth: "600px", lineHeight: "1.5" }}>{details}</p>
          <button
            onClick={handleBookVisit}
            style={{
              marginTop: "20px",
              padding: "10px 20px",
              backgroundColor: "black",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
          >
            Book the visit
          </button>
        </div>

        {/* Google Map */}
        <div
          style={{
            flex: 1,
            minWidth: "320px",
            marginLeft: "20px",
            marginTop: "1rem",
          }}
        >
          <iframe
            title="Property Location"
            src={`https://www.google.com/maps?q=${encodeURIComponent(
              address || location
            )}&output=embed`}
            loading="lazy"
            allowFullScreen
            style={{
              width: "100%",
              height: "300px",
              border: "none",
              borderRadius: "12px",
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            }}
          ></iframe>
          <div style={{ marginTop: "10px" }}>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                address || location
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: "blue", textDecoration: "underline" }}
            >
              View on Google Maps
            </a>
          </div>
        </div>
      </div>

      {/* Booking Form Popup */}
      {showBookingForm && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: "30px",
              borderRadius: "8px",
              width: "400px",
              maxWidth: "90%",
              position: "relative",
            }}
          >
            <button
              onClick={handleClose}
              style={{
                position: "absolute",
                top: "10px",
                right: "10px",
                background: "transparent",
                border: "none",
                fontSize: "18px",
                cursor: "pointer",
              }}
              aria-label="Close booking form"
            >
              ✖
            </button>
            <h3 style={{ marginBottom: "20px" }}>Book Your Visit</h3>

            <form onSubmit={handleBookingSubmit}>
              <input
                name="name"
                type="text"
                placeholder="Your Name"
                required
                style={inputStyle}
              />
              <input
                name="email"
                type="email"
                placeholder="Your Email"
                required
                style={inputStyle}
              />
              <input
                name="date"
                type="date"
                required
                style={inputStyle}
                ref={dateInputRef}
                onClick={() => {
                  if (dateInputRef.current?.showPicker)
                    dateInputRef.current.showPicker();
                  else dateInputRef.current.focus();
                }}
              />
              <textarea
                name="notes"
                placeholder="Additional Notes"
                style={{ ...inputStyle, height: "80px" }}
              ></textarea>
              <button
                type="submit"
                style={{
                  ...inputStyle,
                  backgroundColor: "black",
                  color: "white",
                  cursor: "pointer",
                }}
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      )}
      <Footer />
    </>
  );
};

const inputStyle = {
  width: "100%",
  padding: "10px",
  marginBottom: "10px",
  borderRadius: "5px",
  border: "1px solid #ccc",
};

export default PropertyDetail;
