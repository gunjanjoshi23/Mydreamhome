import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AdminLogin = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5500/admin",
        formData,
        { withCredentials: true }
      );
      localStorage.setItem("admin", JSON.stringify(response.data));
      navigate("/admindashboard");
    } catch (error) {
      setMessage(error.response?.data?.message || "Admin login failed");
    }
  };

  useEffect(() => {
    const canvas = document.getElementById("magic-cursor");
    const ctx = canvas.getContext("2d");

    let particles = [];
    let mouse = { x: 0, y: 0 };

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();

    class MagicParticle {
      constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = Math.random() * 5 + 1;
        this.baseColor = `hsl(${Math.random() * 360}, 100%, 50%)`;
        this.opacity = 1;
        this.speedX = Math.random() * 3 - 1.5;
        this.speedY = Math.random() * 3 - 1.5;
      }

      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        this.opacity -= 0.02;
      }

      draw() {
        ctx.globalAlpha = this.opacity;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.baseColor;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }

    function handleMouseMove(event) {
      mouse.x = event.clientX;
      mouse.y = event.clientY;

      for (let i = 0; i < 5; i++) {
        particles.push(new MagicParticle(mouse.x, mouse.y));
      }
    }

    window.addEventListener("mousemove", handleMouseMove);

    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((particle, index) => {
        particle.update();
        particle.draw();

        if (particle.opacity <= 0) {
          particles.splice(index, 1);
        }
      });
      requestAnimationFrame(animate);
    }

    animate();

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, []);

  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundImage: "url('https://www.carsiceland.com/assets/img/blog/173/thingvellir-national-park.webp')",
      backgroundSize: "cover",
      backgroundPosition: "center",
    },
    formWrapper: {
      background: "rgba(255, 255, 255, 0.9)",
      padding: "30px",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "400px",
      width: "100%",
      textAlign: "center",
      zIndex: 1,
    },
    title: {
      fontSize: "24px",
      marginBottom: "15px",
      color: "#333",
    },
    input: {
      width: "100%",
      padding: "10px",
      margin: "8px 0",
      borderRadius: "5px",
      border: "1px solid #ddd",
      fontSize: "16px",
    },
    button: {
      width: "100%",
      padding: "10px",
      marginTop: "10px",
      background: "black",
      color: "white",
      border: "none",
      fontSize: "18px",
      cursor: "pointer",
      borderRadius: "5px",
    },
    errorMessage: {
      color: "red",
      marginTop: "10px",
      fontSize: "14px",
    },
    linkText: {
      marginTop: "10px",
      fontSize: "14px",
    },
  };

  return (
    <div style={styles.container}>
      {/* Magic Cursor Canvas */}
      <canvas
        id="magic-cursor"
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100vw",
          height: "100vh",
          zIndex: 0,
          pointerEvents: "none",
        }}
      ></canvas>

      {/* Login Form */}
      <form style={styles.formWrapper} onSubmit={handleSubmit}>
        <h2 style={styles.title}>Admin Login</h2>
        <div>
          <label>Email</label>
          <input
            type="email"
            name="email"
            placeholder="Enter your email"
            style={styles.input}
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Password</label>
          <input
            type="password"
            name="password"
            placeholder="Enter your password"
            style={styles.input}
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" style={styles.button}>Login</button>
        {message && <p style={styles.errorMessage}>{message}</p>}
        <p style={styles.linkText}>
          <a href="/">Back to Home</a>
        </p>
      </form>
    </div>
  );
};

export default AdminLogin;
