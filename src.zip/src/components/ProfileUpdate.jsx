import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';

const ProfileUpdate = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    contact: '',
    city: '',
    country: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [focusedInput, setFocusedInput] = useState(null);
  const [btnHover, setBtnHover] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('http://localhost:5500/api/user/profile', {
          withCredentials: true,
        });
        setForm({
          name: res.data.name || '',
          email: res.data.email || '',
          contact: res.data.contact || '',
          city: res.data.city || '',
          country: res.data.country || '',
        });
      } catch (err) {
        console.error(err);
        setError('Failed to load profile');
      }
    };
    fetchProfile();
  }, []);

  const handleFocus = (name) => setFocusedInput(name);
  const handleBlur = () => setFocusedInput(null);

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
    setSuccess('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const res = await axios.put('http://localhost:5500/api/user/profile', form, {
        withCredentials: true,
      });
      setSuccess(res.data.message || 'Profile updated successfully.');
    } catch (err) {
      setError(err.response?.data?.message || 'Update failed');
    }
    setLoading(false);
  };

  const styles = {
    pageWrapper: {
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#CBAD7F',
      minHeight: '100vh',
      paddingTop: '20px',
      marginTop: '100px',
      color: '#333',
      paddingBottom: '40px',
    },
    banner: {
      width: "100%",
      textAlign: "center",
      padding: "50px 20px",
      color: "white",
      backgroundImage: "url('https://t4.ftcdn.net/jpg/02/56/10/07/360_F_256100731_qNLp6MQ3FjYtA3Freu9epjhsAj2cwU9c.jpg')",
      backgroundSize: "cover",
      marginBottom: '30px',
      fontSize: '30px',
      fontWeight: 'bold',
      letterSpacing: '1.5px',
      textShadow: '1px 1px 3px rgba(0,0,0,0.7)'
    },
    layout: {
      display: "flex",
      width: "80%",
      margin: "0 auto",
      gap: "20px",
    },
    sidebar: {
      width: "25%",
      background: "#f4f4f4",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: '0 0 5px rgba(0,0,0,0.1)',
      height: 'fit-content'
    },
    sidebarItem: {
      padding: "12px",
      cursor: "pointer",
      borderBottom: "1px solid #ddd",
    },
    sidebarLink: {
      textDecoration: "none",
      color: "#333",
      fontWeight: "bold",
    },
    container: {
      background: '#fff',
      padding: '30px 40px',
      borderRadius: '8px',
      boxShadow: '0 0 10px rgba(0,0,0,0.1)',
      width: '75%',
      boxSizing: 'border-box',
    },
    heading: {
      fontSize: '28px',
      fontWeight: 'bold',
      marginBottom: '30px',
      textAlign: 'center',
      color: '#333',
      letterSpacing: '1px',
    },
    input: {
      width: '100%',
      padding: '12px 15px',
      marginBottom: '20px',
      borderRadius: '5px',
      border: '1px solid #ddd',
      fontSize: '16px',
      color: '#555',
      boxSizing: 'border-box',
      outline: 'none',
      transition: 'border-color 0.3s',
    },
    inputFocus: {
      borderColor: '#CBAD7F',
      boxShadow: '0 0 5px rgba(203, 173, 127, 0.5)',
    },
    button: {
      width: '100%',
      padding: '12px',
      backgroundColor: '#CBAD7F',
      color: '#fff',
      fontWeight: 'bold',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      fontSize: '18px',
      transition: 'background-color 0.3s',
    },
    buttonHover: {
      backgroundColor: '#a3834f',
    },
    error: {
      color: '#dc3545',
      marginBottom: '20px',
      textAlign: 'center',
      fontWeight: 'bold',
    },
    success: {
      color: '#28a745',
      marginBottom: '20px',
      textAlign: 'center',
      fontWeight: 'bold',
    },
  };

  return (
    <>
      <Header />
      <div style={styles.pageWrapper}>
        <div style={styles.banner}>Update Your Profile</div>

        <div style={styles.layout}>
          {/* Sidebar */}
          <div style={styles.sidebar}>
            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
              <li style={styles.sidebarItem}><Link to="/my-bookings" style={styles.sidebarLink}>My Bookings</Link></li>
              <li style={styles.sidebarItem}><Link to="/profile-update" style={styles.sidebarLink}>Profile Update</Link></li>
              <li style={styles.sidebarItem}><Link to="/favourites" style={styles.sidebarLink}>My Favorites</Link></li>
              <li style={styles.sidebarItem}><Link to="/post-testimonial" style={styles.sidebarLink}>Post a Testimonial</Link></li>
              <li style={styles.sidebarItem}><Link to="/my-testimonial" style={styles.sidebarLink}>My Testimonials</Link></li>
            </ul>
          </div>

          {/* Main Form */}
          <div style={styles.container}>
            <h2 style={styles.heading}>Update Profile</h2>
            <form onSubmit={handleSubmit}>
              {['name', 'email', 'contact', 'city', 'country'].map((field) => (
                <input
                  key={field}
                  name={field}
                  type={field === 'email' ? 'email' : 'text'}
                  placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                  value={form[field]}
                  onChange={handleChange}
                  onFocus={() => handleFocus(field)}
                  onBlur={handleBlur}
                  required
                  style={{
                    ...styles.input,
                    ...(focusedInput === field ? styles.inputFocus : {}),
                  }}
                />
              ))}

              {error && <p style={styles.error}>{error}</p>}
              {success && <p style={styles.success}>{success}</p>}

              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(btnHover ? styles.buttonHover : {})
                }}
                disabled={loading}
                onMouseEnter={() => setBtnHover(true)}
                onMouseLeave={() => setBtnHover(false)}
              >
                {loading ? 'Updating...' : 'Update Profile'}
              </button>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ProfileUpdate;
