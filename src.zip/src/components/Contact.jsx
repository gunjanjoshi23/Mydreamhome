// import React, { useState } from 'react';
// import Header from './Header';
// import Footer from './Footer';

// function ContactUs() {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     phone: '',
//     message: ''
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const res = await fetch('http://localhost:5500/api/contact', {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify(formData)
//     });
//     const data = await res.json();
//     alert(data.message);
//   };

//   return (
//     <>
//       <Header />
//       <div style={{
//         display: 'flex',
//         minHeight: '100vh',
//         backgroundImage: `url('https://cdn.i-scmp.com/sites/default/files/styles/landscape_250_99/public/d8/images/canvas/2021/12/01/15b731de-522e-4a2a-9c7f-08a87aaac325_f605087d.jpg?itok=p0Qr_FK2&v=1638339341')`,
//         backgroundSize: 'cover',

//         backgroundPosition: 'center',
//         color: 'white',
//         marginTop: '110px'
//       }}>
//         <div style={{ flex: 1, padding: '60px' }}>
//           <h1 style={{ fontSize: '38px', fontWeight: 'bold' }}>
//             The best way to find<br />your properties and<br />trusted service!
//           </h1>
//           <div style={{ marginTop: '40px' }}>
//             <div style={{ display: 'flex', marginBottom: '20px' }}>
//               <div style={{
//                 height: '30px',
//                 width: '30px',
//                 borderRadius: '50%',
//                 backgroundColor: '#00d084',
//                 color: 'white',
//                 textAlign: 'center',
//                 lineHeight: '30px',
//                 marginRight: '15px'
//               }}>01</div>
//               <div>
//                 <h4 style={{ margin: 0, color: '#00d084' }}>What makes us preferred choice.</h4>
//                 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
//               </div>
//             </div>
//             <div style={{ display: 'flex' }}>
//               <div style={{
//                 height: '30px',
//                 width: '30px',
//                 borderRadius: '50%',
//                 border: '2px solid #00d084',
//                 color: '#00d084',
//                 textAlign: 'center',
//                 lineHeight: '26px',
//                 marginRight: '15px'
//               }}>02</div>
//               <div>
//                 <h4 style={{ margin: 0, color: '#00d084' }}>Mile financing in real estate.</h4>
//                 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div style={{
//           flex: 1,
//           backgroundColor: '#30e3ca',
//           margin: '60px',
//           borderRadius: '10px',
//           padding: '40px',
//           display: 'flex',
//           flexDirection: 'column',
//           justifyContent: 'center'
//         }}>
//           <h2 style={{ textAlign: 'center', marginBottom: '30px' }}>GET A FREE QUOTE!</h2>
//           <form onSubmit={handleSubmit}>
//             <input type="text" name="name" placeholder="*Your Name" required value={formData.name} onChange={handleChange}
//               style={inputStyle} />
//             <input type="email" name="email" placeholder="*Your Email" required value={formData.email} onChange={handleChange}
//               style={inputStyle} />
//             <input type="text" name="phone" placeholder="Your Phone" value={formData.phone} onChange={handleChange}
//               style={inputStyle} />
//             <textarea name="message" placeholder="Your Message" value={formData.message} onChange={handleChange}
//               rows={4} style={{ ...inputStyle, resize: 'none' }} />
//             <button type="submit" style={buttonStyle}>SEND MESSAGE</button>
//           </form>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// }

// const inputStyle = {
//   width: '100%',
//   padding: '12px',
//   marginBottom: '15px',
//   border: 'none',
//   borderRadius: '4px'
// };

// const buttonStyle = {
//   width: '100%',
//   padding: '12px',
//   backgroundColor: '#0d1b2a',
//   color: 'white',
//   border: 'none',
//   borderRadius: '4px',
//   fontWeight: 'bold',
//   cursor: 'pointer'
// };

// export default ContactUs;


import React, { useState } from 'react';
import Header from './Header';
import Footer from './Footer';

function ContactUs() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:5500/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      alert(data.message);

      // Page refresh after submission
      window.location.reload();
    } catch (error) {
      alert('Something went wrong. Please try again.');
      console.error(error);
    }
  };

  return (
    <>
      <Header />
      <div
        style={{
          display: 'flex',
          minHeight: '100vh',
          backgroundImage: `url('https://cdn.i-scmp.com/sites/default/files/styles/landscape_250_99/public/d8/images/canvas/2021/12/01/15b731de-522e-4a2a-9c7f-08a87aaac325_f605087d.jpg?itok=p0Qr_FK2&v=1638339341')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          color: 'white',
          marginTop: '110px',
        }}
      >
        <div style={{ flex: 1, padding: '60px' }}>
          <h1 style={{ fontSize: '38px', fontWeight: 'bold' }}>
            The best way to find
            <br />
            your properties and
            <br />
            trusted service!
          </h1>
          <div style={{ marginTop: '40px' }}>
            <div style={{ display: 'flex', marginBottom: '20px' }}>
              <div
                style={{
                  height: '30px',
                  width: '30px',
                  borderRadius: '50%',
                  backgroundColor: '#00d084',
                  color: 'white',
                  textAlign: 'center',
                  lineHeight: '30px',
                  marginRight: '15px',
                }}
              >
                01
              </div>
              <div>
                <h4 style={{ margin: 0, color: '#00d084' }}>
                  What makes us preferred choice.
                </h4>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p>
              </div>
            </div>
            <div style={{ display: 'flex' }}>
              <div
                style={{
                  height: '30px',
                  width: '30px',
                  borderRadius: '50%',
                  border: '2px solid #00d084',
                  color: '#00d084',
                  textAlign: 'center',
                  lineHeight: '26px',
                  marginRight: '15px',
                }}
              >
                02
              </div>
              <div>
                <h4 style={{ margin: 0, color: '#00d084' }}>
                  Mile financing in real estate.
                </h4>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div
          style={{
            flex: 1,
            backgroundColor: '#30e3ca',
            margin: '60px',
            borderRadius: '10px',
            padding: '40px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
          }}
        >
          <h2 style={{ textAlign: 'center', marginBottom: '30px' }}>
            GET A FREE QUOTE!
          </h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="*Your Name"
              required
              value={formData.name}
              onChange={handleChange}
              style={inputStyle}
            />
            <input
              type="email"
              name="email"
              placeholder="*Your Email"
              required
              value={formData.email}
              onChange={handleChange}
              style={inputStyle}
            />
            <input
              type="text"
              name="phone"
              placeholder="Your Phone"
              value={formData.phone}
              onChange={handleChange}
              style={inputStyle}
            />
            <textarea
              name="message"
              placeholder="Your Message"
              value={formData.message}
              onChange={handleChange}
              rows={4}
              style={{ ...inputStyle, resize: 'none' }}
            />
            <button type="submit" style={buttonStyle}>
              SEND MESSAGE
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </>
  );
}

const inputStyle = {
  width: '100%',
  padding: '12px',
  marginBottom: '15px',
  border: 'none',
  borderRadius: '4px',
};

const buttonStyle = {
  width: '100%',
  padding: '12px',
  backgroundColor: '#0d1b2a',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  fontWeight: 'bold',
  cursor: 'pointer',
};

export default ContactUs;

