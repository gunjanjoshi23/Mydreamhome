// // src/components/Signup.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Signup = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [contact, setContact] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const response = await axios.post(
        'http://localhost:5500/api/signup',
        { name, contact, email, password, confirmPassword, city, country },
        { withCredentials: true }
      );
      alert('Signup successful');
      navigate('/login');
    } catch (err) {
      if (err.response && err.response.data && err.response.data.error) {
        setError(err.response.data.error);
      } else {
        setError('Signup failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <div style={styles.left}>
          <img
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c"
            alt="Signup Illustration"
            style={styles.image}
          />
        </div>
        <div style={styles.right}>
          <img
            src="https://cdn.auth0.com/quantum-assets/dist/latest/logos/auth0/auth0-icon-onlight.svg"
            alt="logo"
            style={{ width: '50px', marginBottom: 20 }}
          />
          <h2>Create an Account</h2>
          <p style={styles.subText}>Sign up for My Dream Home</p>

          <form onSubmit={handleSignup} style={styles.form}>
            <input
              type="text"
              placeholder="Full Name*"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="email"
              placeholder="Email address*"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="text"
              placeholder="Contact Number*"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="text"
              placeholder="City*"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="text"
              placeholder="Country*"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="password"
              placeholder="Password*"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={styles.input}
            />
            <input
              type="password"
              placeholder="Confirm Password*"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              style={styles.input}
            />
            {error && <p style={styles.error}>{error}</p>}
            <button type="submit" style={styles.button} disabled={loading}>
              {loading ? 'Signing up...' : 'Sign Up'}
            </button>
          </form>

          <p style={styles.signupText}>
            Already have an account?{' '}
            <a href="/login" style={styles.link}>
              Log in
            </a>
          </p>

          <div style={styles.orContainer}>
            <hr style={styles.hr} />
            <span style={styles.or}>OR</span>
            <hr style={styles.hr} />
          </div>

          <a
            href="http://localhost:5500/auth/google"
            style={{ ...styles.googleBtn, textDecoration: 'none', color: '#000' }}
          >
            <img
              src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Cpath fill='%23FBBC05' d='M0 37V11l17 13z'/%3E%3Cpath fill='%23EA4335' d='M0 11l17 13 7-6.1L48 14V0H0z'/%3E%3Cpath fill='%2334A853' d='M0 37l30-23 7.9 1L48 0v48H0z'/%3E%3Cpath fill='%234285F4' d='M48 48L17 24l-4-3 35-10z'/%3E%3C/svg%3E"
              alt="Google"
              style={{ width: 20, marginRight: 10 }}
            />
            Sign up with Google
          </a>

          <a href="/" style={{ ...styles.link, display: 'block', marginBottom: '1rem', marginTop: '2rem' }}>
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundColor: 'Teal',
    padding: '0 10px',
  },
  card: {
    display: 'flex',
    backgroundColor: 'white',
    borderRadius: 8,
    boxShadow: '0 0 10px rgba(0,0,0,0.1)',
    overflow: 'hidden',
    width: '90%',
    maxWidth: '1000px',
    minHeight: '600px',
  },
  left: {
    flex: 1,
    backgroundColor: '#eee',
  },
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  right: {
    flex: 1,
    padding: '2rem',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  input: {
    padding: '0.8rem',
    borderRadius: 4,
    border: '1px solid #ccc',
    fontSize: '1rem',
  },
  button: {
    backgroundColor: '#0057ff',
    color: 'white',
    padding: '0.8rem',
    border: 'none',
    borderRadius: 4,
    fontSize: '1rem',
    cursor: 'pointer',
  },
  link: {
    color: '#0057ff',
    textDecoration: 'none',
  },
  signupText: {
    marginTop: '1rem',
  },
  orContainer: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    margin: '1rem 0',
  },
  or: {
    fontSize: '0.9rem',
    color: '#aaa',
  },
  hr: {
    flex: 1,
    border: 'none',
    borderBottom: '1px solid #ccc',
  },
  googleBtn: {
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    padding: '0.7rem',
    borderRadius: 4,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  error: {
    color: 'red',
    fontSize: '0.9rem',
  },
  subText: {
    fontSize: '0.9rem',
    color: '#555',
  },
};

export default Signup;


// src/components/Signup.jsx
// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const Signup = () => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [contact, setContact] = useState("");
//   const [city, setCity] = useState("");
//   const [country, setCountry] = useState("");
//   const [password, setPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [error, setError] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [isHovered, setIsHovered] = useState(false);

//   const navigate = useNavigate();

//   const handleSignup = async (e) => {
//     e.preventDefault();
//     if (password !== confirmPassword) {
//       setError("Passwords do not match");
//       return;
//     }
//     setError("");
//     setLoading(true);
//     try {
//       const response = await axios.post(
//         "http://localhost:5500/api/signup",
//         { name, contact, email, password, confirmPassword, city, country },
//         { withCredentials: true }
//       );
//       alert("Signup successful");
//       navigate("/login");
//     } catch (err) {
//       if (err.response && err.response.data && err.response.data.error) {
//         setError(err.response.data.error);
//       } else {
//         setError("Signup failed. Please try again.");
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Color for shadows and accent
//   const accentColor = "pink";

//   return (
//     <div style={styles.container}>
//       <div
//         style={{
//           ...styles.card(accentColor),
//           ...(isHovered ? styles.cardHover : {}),
//         }}
//         onMouseEnter={() => setIsHovered(true)}
//         onMouseLeave={() => setIsHovered(false)}
//       >
//         {/* <div style={styles.badge(accentColor)}>Sign Up</div> */}

//         {/* <img
//           src="https://cdn.auth0.com/quantum-assets/dist/latest/logos/auth0/auth0-icon-onlight.svg"
//           alt="logo"
//           style={{ width: "50px", marginBottom: 20,marginTop:30,marginLeft:170, }}
//         /> */}
//         <h2 style={styles.title}>Create an Account</h2>
//         <p style={{ ...styles.text, marginBottom: "1rem" }}>
//           Sign up for My Dream Home
//         </p>

//         <form onSubmit={handleSignup} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
//           <input
//             type="text"
//             placeholder="Full Name*"
//             value={name}
//             onChange={(e) => setName(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="email"
//             placeholder="Email address*"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="text"
//             placeholder="Contact Number*"
//             value={contact}
//             onChange={(e) => setContact(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="text"
//             placeholder="City*"
//             value={city}
//             onChange={(e) => setCity(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="text"
//             placeholder="Country*"
//             value={country}
//             onChange={(e) => setCountry(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="password"
//             placeholder="Password*"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           <input
//             type="password"
//             placeholder="Confirm Password*"
//             value={confirmPassword}
//             onChange={(e) => setConfirmPassword(e.target.value)}
//             required
//             style={inputStyle}
//           />
//           {error && <p style={{ color: "tomato", fontSize: "0.9rem" }}>{error}</p>}
//           <button
//             type="submit"
//             style={{
//               backgroundColor: accentColor,
//               color: "#fff",
//               padding: "10px",
//               borderRadius: 5,
//               border: "none",
//               fontWeight: "bold",
//               cursor: loading ? "not-allowed" : "pointer",
//             }}
//             disabled={loading}
//           >
//             {loading ? "Signing up..." : "Sign Up"}
//           </button>
//         </form>

//         <p style={{ ...styles.text, marginTop: 15 }}>
//           Already have an account?{" "}
//           <a href="/login" style={styles.link(accentColor)}>
//             Log in
//           </a>
//         </p>

//         <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "20px 0" }}>
//           <hr style={{ flex: 1, borderColor: "#444" }} />
//           <span style={{ color: "#888", fontSize: 14 }}>OR</span>
//           <hr style={{ flex: 1, borderColor: "#444" }} />
//         </div>

//         <a
//           href="http://localhost:5500/auth/google"
//           style={{
//             backgroundColor: "white",
//             borderRadius: 5,
//             padding: "10px",
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//             textDecoration: "none",
//             color: "#000",
//             fontWeight: "bold",
//             userSelect: "none",
//           }}
//         >
//           <img
//             src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Cpath fill='%23FBBC05' d='M0 37V11l17 13z'/%3E%3Cpath fill='%23EA4335' d='M0 11l17 13 7-6.1L48 14V0H0z'/%3E%3Cpath fill='%2334A853' d='M0 37l30-23 7.9 1L48 0v48H0z'/%3E%3Cpath fill='%234285F4' d='M48 48L17 24l-4-3 35-10z'/%3E%3C/svg%3E"
//             alt="Google"
//             style={{ width: 20, marginRight: 10 }}
//           />
//           Sign up with Google
//         </a>

//         <a
//           href="/"
//           style={{
//             ...styles.link(accentColor),
//             display: "block",
//             marginTop: "2rem",
//             textAlign: "center",
//           }}
//         >
//           ← Back to Home
//         </a>
//       </div>
//     </div>
//   );
// };

// const inputStyle = {
//   padding: "10px",
//   borderRadius: "6px",
//   border: "1px solid #444",
//   backgroundColor: "#222",
//   color: "#fff",
//   fontSize: "1rem",
//   outline: "none",
//   transition: "border-color 0.3s",
// };

// inputStyle["::placeholder"] = {
//   color: "#888",
// };

// const styles = {
//   container: {
//     display: "flex",
//     justifyContent: "center",
//     gap: "40px",
//     padding: "40px",
//     backgroundColor: "#5b7b7a",
//     minHeight: "100vh",
//   },
//   card: (color) => ({
//     position: "relative",
//     backgroundColor: "Teal",
//     width: "480px",
//     padding: "20px",
//     borderRadius: "10px",
//     color: "#fff",
//     boxShadow: `0 0 20px ${color}`,
//     transition: "transform 0.3s",
//     cursor: "pointer",
//   }),
//   cardHover: {
//     transform: "scale(1.05)",
//   },
//   badge: (color) => ({
//     position: "absolute",
//     top: "10px",
//     left: "10px",
//     backgroundColor: "#000",
//     border: `2px solid ${color}`,
//     padding: "8px",
//     borderRadius: "5px",
//     fontSize: "12px",
//     textAlign: "center",
//     color,
//   }),
//   title: {
//     fontSize: "22px",
//     margin: "50px 0 10px 0",
//   },
//   text: {
//     fontSize: "14px",
//     lineHeight: "1.6",
//   },
//   link: (color) => ({
//     marginTop: "15px",
//     display: "inline-block",
//     color,
//     fontWeight: "bold",
//     textDecoration: "none",
//   }),
// };

// export default Signup;

