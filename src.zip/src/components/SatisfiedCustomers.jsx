import React, { useEffect, useState } from 'react';
import axios from 'axios';

const SatisfiedCustomers = () => {
    const [testimonials, setTestimonials] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const fetchTestimonials = async () => {
            try {
                const res = await axios.get('http://localhost:5500/api/testimonials', { withCredentials: true });
                if (res.data.success && Array.isArray(res.data.testimonials)) {
                    setTestimonials(res.data.testimonials);
                } else {
                    console.error("Invalid response format:", res.data);
                    setTestimonials([]);
                }
            } catch (error) {
                console.error("Error fetching testimonials:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchTestimonials();
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex(prevIndex =>
                (prevIndex + 1) % testimonials.length
            );
        }, 4000);
        return () => clearInterval(interval);
    }, [testimonials]);

    return (
        <div style={styles.wrapper}>
            <div style={styles.overlay}></div>

            <div style={styles.container}>
                <h2 style={styles.title}>
                    <span style={{ color: "#fff" }}>Customer feedback and experiences</span>
                </h2>

                <p style={styles.reviewHighlight}> 127k Excellent Reviews</p>
                <p style={styles.reviewHighlight}>⭐⭐⭐⭐⭐ </p>

                {loading ? (
                    <p style={{ color: '#fff' }}>Loading testimonials...</p>
                ) : testimonials.length > 0 ? (
                    <div style={styles.slider}>
                        <div style={styles.card}>
                            <div style={styles.iconWrapper}>
                                <img
                                    src="https://cdn4.vectorstock.com/i/1000x1000/72/93/online-testimonial-logo-icon-design-vector-22947293.jpg"
                                    alt="user"
                                    style={styles.icon}
                                />
                            </div>
                            <h3 style={styles.name}>{testimonials[currentIndex]?.user?.name || 'Anonymous'}</h3>
                            <p style={styles.message}>{testimonials[currentIndex]?.testimonial}</p>
                        </div>
                    </div>
                ) : (
                    <p style={{ color: '#fff' }}>No testimonials available.</p>
                )}
            </div>
        </div>
    );
};

const styles = {
    wrapper: {
        position: 'relative',
        backgroundImage: 'url("https://www.pixelstalk.net/wp-content/uploads/images1/House-Wallpapers-HD-Free-download.jpg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        padding: '100px 20px',
        color: 'white',
        zIndex: 1,
    },
    overlay: {
        position: 'absolute',
        top: 0, left: 0, right: 0, bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        zIndex: 2
    },
    container: {
        position: 'relative',
        zIndex: 3,
        textAlign: 'center',
        maxWidth: '800px',
        margin: '0 auto'
    },
    title: {
        fontSize: '36px',
        fontWeight: 'bold',
        marginBottom: '20px',
        color: '#ccc'
    },
    reviewHighlight: {
        color: '#FFD700', // gold color for stars
        fontSize: '20px',
        marginBottom: '30px',
        fontWeight: '600',
    },
    slider: {
        transition: 'all 0.5s ease-in-out',
    },
    card: {
        background: 'rgba(255, 255, 255, 0.2)',
        borderRadius: '15px',
        padding: '20px',
        boxShadow: '0 4px 10px rgba(0,0,0,0.2)',
        textAlign: 'center',
        backdropFilter: 'blur(10px)',
        height: '100%',
        maxWidth: '500px',
        margin: '0 auto'
    },
    iconWrapper: {
        width: '80px',
        height: '80px',
        margin: '0 auto 15px',
        background: '#004aad',
        borderRadius: '50%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    icon: {
        width: '40px',
        height: '40px',
        filter: 'invert(100%)'
    },
    name: {
        fontSize: '18px',
        fontWeight: 'bold',
        marginBottom: '10px',
        color: '#fff'
    },
    message: {
        fontSize: '14px',
        color: '#eee'
    }
};

export default SatisfiedCustomers;
