import React, { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from './Sidebar'; // Adjust path as needed

const AdminManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    const fetchUsers = async () => {
      const res = await axios.get(
        `http://localhost:5500/admin-manageprofile?page=${currentPage}&limit=${limit}&search=${searchTerm}`
      );
      setUsers(res.data.users);
      setTotalPages(res.data.totalPages);
    };

    const timer = setTimeout(() => fetchUsers(), 300);
    return () => clearTimeout(timer);
  }, [searchTerm, currentPage, limit]);

  const deleteUser = async (id) => {
    if (window.confirm("Are you sure to delete this user?")) {
      await axios.delete(`http://localhost:5500/delete/${id}`);
      setUsers(users.filter((user) => user._id !== id));
    }
  };

  return (
    
    <div style={{ display: "flex" ,  backgroundColor:"#FFE4CF"

}}>
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div style={{ padding: "20px", fontFamily: "Arial", flex: 1 }}>
        <h2>User Management</h2>

        <input
          type="text"
          placeholder="Search users..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            padding: "8px",
            marginBottom: "15px",
            width: "250px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#f0f0f0" }}>
              <th style={th}>S.NO</th>
              <th style={th}>Name</th>
              <th style={th}>Email</th>
              <th style={th}>Phone</th>
              <th style={th}>Location</th>
              <th style={th}>Registered On</th>
              <th style={th}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={u._id} style={{ textAlign: "center" }}>
                <td style={td}>{(currentPage - 1) * limit + i + 1}</td>
                <td style={td}>{u.name}</td>
                <td style={td}>{u.email}</td>
                <td style={td}>{u.contact || "-"}</td>
                <td style={td}>{[u.city, u.country].filter(Boolean).join(", ")}</td>
                <td style={td}>
                  {new Date(u.registrationDate).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                  })}
                </td>
                <td style={td}>
                  <button onClick={() => deleteUser(u._id)} style={deleteBtn}>
                    Delete
                  </button>
                </td>
              </tr>

            ))}
          </tbody>
        </table>

        <div style={{ marginTop: "15px" }}>
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            style={paginationBtn}
          >
            Previous
          </button>
          <span style={{ margin: "0 10px" }}>
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            style={paginationBtn}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

const th = {
  padding: "10px",
  borderBottom: "1px solid #ccc",
};

const td = {
  padding: "8px",
  borderBottom: "1px solid #eee",
};

const deleteBtn = {
  padding: "6px 12px",
  backgroundColor: "#dc3545",
  color: "white",
  border: "none",
  borderRadius: "4px",
  cursor: "pointer",
};

const paginationBtn = {
  padding: "6px 12px",
  margin: "0 5px",
  backgroundColor: "#007bff",
  color: "white",
  border: "none",
  borderRadius: "4px",
  cursor: "pointer",
};

export default AdminManageUsers;
