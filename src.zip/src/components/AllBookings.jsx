import React, { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "./Sidebar";

const AllBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get("http://localhost:5500/api/booking");
        const sortedBookings = response.data.sort((a, b) => new Date(b.date) - new Date(a.date));
        setBookings(sortedBookings);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        alert("Failed to load bookings. Please try again later.");
        setLoading(false);
      }
    };
    fetchBookings();
  }, []);

  const updateBookingStatus = async (id, status) => {
    const confirm = window.confirm(`Are you sure you want to ${status} this booking?`);
    if (!confirm) return;

    setUpdatingId(id);
    try {
      await axios.put(`http://localhost:5500/api/booking/${id}`, { status });
      alert(`Booking has been ${status}!`);
      setBookings((prev) =>
        prev.map((b) => (b._id === id ? { ...b, status } : b))
      );
    } catch (err) {
      console.error("Error updating booking:", err);
      alert("Failed to update booking.");
    }
    setUpdatingId(null);
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case "pending":
        return { background: "yellow", color: "black", padding: "5px", borderRadius: "5px" };
      case "confirmed":
        return { background: "green", color: "white", padding: "5px", borderRadius: "5px" };
      case "cancelled":
        return { background: "red", color: "white", padding: "5px", borderRadius: "5px" };
      default:
        return {};
    }
  };

  const styles = {
    layout: { display: "flex", minHeight: "100vh", backgroundColor: '#b48e92' },
    content: { flex: 1, padding: "20px", fontFamily: "Arial" },
    heading: { textAlign: "center", marginBottom: "20px", fontSize: "24px" },
    table: { width: "100%", borderCollapse: "collapse", marginTop: "10px" },
    th: { background: "#007bff", color: "#fff", padding: "10px", border: "1px solid #ddd" },
    td: { padding: "10px", border: "1px solid #ddd" },
    button: { padding: "5px 10px", borderRadius: "5px", cursor: "pointer", marginRight: "5px" },
    confirmButton: { background: "green", color: "white" },
    cancelButton: { background: "red", color: "white" },
    disabledButton: { opacity: 0.5, cursor: "not-allowed" },
  };

  return (
    <div style={styles.layout}>
      <Sidebar />
      <div style={styles.content}>
        <h2 style={styles.heading}>All Property Bookings</h2>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>S.No</th>
              <th style={styles.th}>Property</th>
              <th style={styles.th}>User</th>
              <th style={styles.th}>Email</th>
              <th style={styles.th}>Date</th>
              <th style={styles.th}>Status</th>
              <th style={styles.th}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td style={styles.td} colSpan="7">Loading bookings...</td>
              </tr>
            ) : bookings.length > 0 ? (
              bookings.map((booking, index) => (
                <tr key={booking._id}>
                  <td style={styles.td}>{index + 1}</td>
                  <td style={styles.td}>{booking.location || "Unknown"}</td>
                  <td style={styles.td}>{booking.name || "Unknown"}</td>
                  <td style={styles.td}>{booking.email || "Unknown"}</td>
                  <td style={styles.td}>
                    {new Date(booking.date).toLocaleDateString()}
                  </td>
                  <td style={{ ...styles.td, ...getStatusStyle(booking.status) }}>
                    {booking.status}
                  </td>
                  <td style={styles.td}>
                    {booking.status === "pending" ? (
                      <>
                        <button
                          style={{
                            ...styles.button,
                            ...styles.confirmButton,
                            ...(updatingId === booking._id ? styles.disabledButton : {}),
                          }}
                          onClick={() => updateBookingStatus(booking._id, "confirmed")}
                          disabled={updatingId === booking._id}
                        >
                          {updatingId === booking._id ? "Updating..." : "Confirm"}
                        </button>
                        <button
                          style={{
                            ...styles.button,
                            ...styles.cancelButton,
                            ...(updatingId === booking._id ? styles.disabledButton : {}),
                          }}
                          onClick={() => updateBookingStatus(booking._id, "cancelled")}
                          disabled={updatingId === booking._id}
                        >
                          {updatingId === booking._id ? "Updating..." : "Cancel"}
                        </button>
                      </>
                    ) : (
                      "-"
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td style={styles.td} colSpan="7">No bookings found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AllBookings;
