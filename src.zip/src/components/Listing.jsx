import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FaBed, FaBath, FaCar, FaHeart, FaStar, FaArrowsAltH } from 'react-icons/fa';
import { MdMeetingRoom } from 'react-icons/md';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';

const styles = {
  container: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
    gap: '20px',
    padding: '40px 20px',
    backgroundColor: '#0a0a0a',
    minHeight: '100vh',
  },
  card: (color) => ({
    position: 'relative',
    backgroundColor: '#111',
    padding: '20px',
    borderRadius: '10px',
    color: '#fff',
    boxShadow: `0 0 20px ${color}`,
    transition: 'transform 0.3s',
    cursor: 'pointer',
  }),
  cardHover: {
    transform: 'scale(1.05)',
  },
  badge: (color) => ({
    position: 'absolute',
    top: '10px',
    left: '10px',
    backgroundColor: '#000',
    border: `2px solid ${color}`,
    padding: '8px',
    borderRadius: '5px',
    fontSize: '12px',
    textAlign: 'center',
    color,
  }),
  title: {
    fontSize: '22px',
    margin: '10px 0 10px 0',
  },
  text: {
    fontSize: '14px',
    lineHeight: '1.6',
  },
  link: (color) => ({
    marginTop: '15px',
    display: 'inline-block',
    color: 'black',
    fontWeight: 'bold',
    textDecoration: 'none',
    padding: '10px 20px',
    borderRadius: '8px',
    backgroundColor: color,
  }),
  searchInput: {
    padding: '10px',
    width: '300px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    fontSize: '16px',
    marginBottom: '30px',
  },
  likeIcon: (liked) => ({
    position: 'absolute',
    top: 12,
    right: 12,
    color: liked ? 'red' : '#fff',
    background: 'rgba(0,0,0,0.3)',
    padding: '6px',
    borderRadius: '50%',
    cursor: 'pointer',
  }),
};

const Listing = () => {
  const [properties, setProperties] = useState([]);
  const [liked, setLiked] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [hovered, setHovered] = useState(null);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const res = await axios.get('http://localhost:5500/api/properties');
        setProperties(res.data);
      } catch (err) {
        console.error('Error fetching properties:', err);
      }
    };
    fetchProperties();
  }, []);

  const toggleLike = (id) => {
    setLiked((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const filteredProperties = properties.filter((property) => {
    const title = property.title ?? '';
    const location = property.location ?? '';
    return (
      title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <>
      <Header />
      <section
        style={{
          paddingTop: '150px',
          background: '#f4f8ec',
          minHeight: '100vh',
        }}
      >
        <div style={{ textAlign: 'left', padding: '0 20px' }}>
          <input
            type="text"
            placeholder="Search by title or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={styles.searchInput}
          />
        </div>

        <div style={styles.container}>
          {filteredProperties.map((property) => {
            const shadowColor = 'limegreen';

            return (
              <div
                key={property._id}
                style={{
                  ...styles.card(shadowColor),
                  ...(hovered === property._id ? styles.cardHover : {}),
                }}
                onMouseEnter={() => setHovered(property._id)}
                onMouseLeave={() => setHovered(null)}
              >
                <div style={{ position: 'relative' }}>
                  <Link to={`/property/${property._id}`}>
                    <img
                      src={`http://localhost:5500${property.image}`}
                      alt={property.title}
                      style={{
                        width: '100%',
                        height: '220px',
                        objectFit: 'cover',
                        borderRadius: '10px',
                      }}
                    />
                  </Link>
                  <FaHeart
                    onClick={() => toggleLike(property._id)}
                    style={styles.likeIcon(liked[property._id])}
                  />
                  <div style={styles.badge(shadowColor)}>{property.location}</div>
                </div>
                <h3 style={styles.title}>{property.title}</h3>
                <span style={{ fontWeight: 'bold', fontSize: '16px', color: 'limegreen' }}>
                  ${property.price}
                </span>
                <div
                  style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '10px',
                    fontSize: '14px',
                    color: '#ccc',
                    marginTop: '8px',
                  }}
                >
                  <span>
                    <FaBed /> {property.beds}
                  </span>
                  <span>
                    <FaBath /> {property.baths}
                  </span>
                  <span>
                    <MdMeetingRoom /> {property.rooms}
                  </span>
                  <span>
                    <FaCar /> {property.parking}
                  </span>
                  <span>
                    <FaArrowsAltH /> {property.size}
                  </span>
                  <span>
                    <FaStar style={{ color: 'gold' }} /> {property.rating}
                  </span>
                </div>
                <p style={styles.text}>
                  {property.details?.length > 200
                    ? property.details.slice(0, 200) + '...'
                    : property.details}
                </p>
                <Link to={`/property/${property._id}`} style={styles.link('limegreen')}>
                  Book Now
                </Link>
              </div>
            );
          })}
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Listing;
