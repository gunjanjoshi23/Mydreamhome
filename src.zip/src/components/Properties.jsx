

// // src/components/Properties.js
// import React, { useEffect, useState } from 'react';
// import { Link } from 'react-router-dom';
// import { VscSettings } from 'react-icons/vsc';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import { Autoplay } from 'swiper/modules';
// import { FaBed, FaBath, FaCar, FaHeart, FaStar, FaArrowsAltH } from 'react-icons/fa';
// import { MdMeetingRoom } from 'react-icons/md';
// import axios from 'axios';
// import 'swiper/css';
// import 'swiper/css/pagination';

// const Properties = () => {
//   const [properties, setProperties] = useState([]);
//   const [liked, setLiked] = useState({});
//   const [isLoggedIn, setIsLoggedIn] = useState(false);

//   useEffect(() => {
//     const token = localStorage.getItem('token');
//     setIsLoggedIn(!!token);
//   }, []);

//   useEffect(() => {
//     const fetchProperties = async () => {
//       try {
//         const res = await axios.get('http://localhost:5500/api/properties');
//         setProperties(res.data);

//         if (isLoggedIn) {
//           const favRes = await axios.get('http://localhost:5500/api/favorites', {
//             headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
//           });
//           const favObj = {};
//           favRes.data.forEach(fav => {
//             favObj[fav.propertyId] = true;
//           });
//           setLiked(favObj);
//         } else {
//           const guestFav = JSON.parse(localStorage.getItem('guestFavorites')) || [];
//           const favObj = {};
//           guestFav.forEach(id => { favObj[id] = true });
//           setLiked(favObj);
//         }
//       } catch (err) {
//         console.error('Error fetching properties or favorites:', err);
//       }
//     };
//     fetchProperties();
//   }, [isLoggedIn]);

//   const toggleLike = async (id) => {
//     if (isLoggedIn) {
//       try {
//         if (!liked[id]) {
//           await axios.post('http://localhost:5500/api/favorites', { propertyId: id }, {
//             headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
//           });
//         } else {
//           await axios.delete(`http://localhost:5500/api/favorites/${id}`, {
//             headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
//           });
//         }
//         setLiked(prev => ({ ...prev, [id]: !prev[id] }));
//       } catch (err) {
//         console.error('Error updating favorites:', err);
//       }
//     } else {
//       const guestFav = JSON.parse(localStorage.getItem('guestFavorites')) || [];
//       let updatedFav;
//       if (!liked[id]) {
//         updatedFav = [...guestFav, id];
//       } else {
//         updatedFav = guestFav.filter(favId => favId !== id);
//       }
//       localStorage.setItem('guestFavorites', JSON.stringify(updatedFav));
//       setLiked(prev => ({ ...prev, [id]: !prev[id] }));
//     }
//   };

//   const styles = {
//     card: (color) => ({
//       position: "relative",
//       backgroundColor: "#111",
//       width: "100%",
//       padding: "20px",
//       borderRadius: "12px",
//       color: "#fff",
//       boxShadow: `0 0 20px ${color}`,
//       transition: "transform 0.3s",
//       cursor: "pointer",
//       minHeight: "550px",
//       display: "flex",
//       flexDirection: "column",
//       justifyContent: "space-between"
//     }),
//     badge: (color) => ({
//       position: "absolute",
//       top: "10px",
//       left: "10px",
//       backgroundColor: "#000",
//       border: `2px solid ${color}`,
//       padding: "8px",
//       borderRadius: "5px",
//       fontSize: "12px",
//       color: color,
//       fontWeight: 600,
//     }),
//   };

//   return (
//     <section style={{ padding: '60px 20px', background: '#0a0a0a' }}>
//       <div style={{ textAlign: 'center', marginBottom: '10px' }}>
//         <span style={{ color: '#7d993e', fontSize: '18px', fontWeight: 600 }}>
//           Your Future Home Awaits!
//         </span>
//         <h2 style={{ fontSize: '36px', fontWeight: 'bold', margin: '10px 0', color: 'white' }}>
//           Find Your Dream Here
//         </h2>
//       </div>

//       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '30px', color: 'white' }}>
//         <h5 style={{ fontSize: '16px' }}>
//           <span style={{ fontWeight: 'bold' }}>Showing 1–{properties.length}</span> of 3k+ properties
//         </h5>
//         <div style={{ display: 'flex', gap: '10px' }}>
//           <Link to="/filter" style={{
//             background: '#82c43c',
//             padding: '8px 12px',
//             borderRadius: '8px',
//             display: 'flex',
//             alignItems: 'center',
//             textDecoration: 'none'
//           }}>
//             <VscSettings size={20} color="#fff" />
//           </Link>
//           <Link to="/favourites" style={{
//             background: '#f44336',
//             padding: '8px 12px',
//             borderRadius: '8px',
//             color: 'white',
//             fontWeight: 'bold',
//             display: 'flex',
//             alignItems: 'center',
//             textDecoration: 'none'
//           }}>
//             Favorites
//           </Link>
//         </div>
//       </div>

//       <Swiper
//         spaceBetween={30}
//         autoplay={{ delay: 4000, disableOnInteraction: false }}
//         breakpoints={{
//           600: { slidesPerView: 1 },
//           900: { slidesPerView: 2 },
//           1300: { slidesPerView: 3 },
//           1500: { slidesPerView: 4 },
//         }}
//         modules={[Autoplay]}
//       >
//         {properties.map((property) => (
//           <SwiperSlide key={property._id}>
//             <div style={styles.card('#83b735')}>
//               <div style={{ position: 'relative' }}>
//                 <img
//                   src={`http://localhost:5500${property.image}`}
//                   alt={property.title}
//                   style={{ width: '100%', height: '220px', objectFit: 'cover', borderRadius: '8px' }}
//                 />
//                 <div style={styles.badge('#83b735')}>{property.location}</div>

//                 <FaHeart
//                   onClick={() => toggleLike(property._id)}
//                   style={{
//                     position: 'absolute',
//                     top: 12,
//                     right: 12,
//                     color: liked[property._id] ? 'red' : '#fff',
//                     background: 'rgba(0,0,0,0.3)',
//                     padding: '6px',
//                     borderRadius: '50%',
//                     cursor: 'pointer'
//                   }}
//                 />
//               </div>

//               <div style={{ marginTop: '16px' }}>
//                 <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
//                   <h3 style={{ fontSize: '18px', fontWeight: 700 }}>{property.name}</h3>
//                   <span style={{ fontWeight: 'bold', color: '#83b735', fontSize: '16px' }}>${property.price}</span>
//                 </div>

//                 <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', fontSize: '14px', color: '#ccc' }}>
//                   <span><FaBed /> {property.beds}</span>
//                   <span><FaBath /> {property.baths}</span>
//                   <span><MdMeetingRoom /> {property.rooms}</span>
//                   <span><FaCar /> {property.parking}</span>
//                   <span><FaArrowsAltH /> {property.size}</span>
//                   <span><FaStar style={{ color: 'gold' }} /> {property.rating}</span>
//                 </div>

//                 <p style={{ fontSize: '16px', color: '#ddd', lineHeight: '1.5', marginTop: '10px' }}>
//                   {property.details?.length > 200
//                     ? property.details.slice(0, 200) + '...'
//                     : property.details}
//                 </p>

//                 <Link to={`/property/${property._id}`} style={{
//                   display: 'inline-block',
//                   backgroundColor: '#83b735',
//                   color: '#fff',
//                   padding: '10px 20px',
//                   borderRadius: '8px',
//                   textDecoration: 'none',
//                   fontWeight: 600,
//                   marginTop: '10px'
//                 }}>
//                   Book Now
//                 </Link>
//               </div>
//             </div>
//           </SwiperSlide>
//         ))}
//       </Swiper>
//     </section>
//   );
// };

// export default Properties;


// src/components/Properties.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { VscSettings } from 'react-icons/vsc';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay } from 'swiper/modules';
import { FaBed, FaBath, FaCar, FaHeart, FaStar, FaArrowsAltH } from 'react-icons/fa';
import { MdMeetingRoom } from 'react-icons/md';
import axios from 'axios';
import 'swiper/css';
import 'swiper/css/pagination';

const Properties = () => {
  const [properties, setProperties] = useState([]);
  const [liked, setLiked] = useState({});
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const res = await axios.get('http://localhost:5500/api/properties');
        setProperties(res.data);

        if (isLoggedIn) {
          const favRes = await axios.get('http://localhost:5500/api/favorites', {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          });
          const favObj = {};
          favRes.data.forEach(fav => {
            favObj[fav.propertyId] = true;
          });
          setLiked(favObj);
        } else {
          const guestFav = JSON.parse(localStorage.getItem('guestFavorites')) || [];
          const favObj = {};
          guestFav.forEach(id => { favObj[id] = true });
          setLiked(favObj);
        }
      } catch (err) {
        console.error('Error fetching properties or favorites:', err);
      }
    };
    fetchProperties();
  }, [isLoggedIn]);

  const toggleLike = async (id) => {
    if (isLoggedIn) {
      try {
        if (!liked[id]) {
          await axios.post('http://localhost:5500/api/favorites', { propertyId: id }, {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          });
        } else {
          await axios.delete(`http://localhost:5500/api/favorites/${id}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          });
        }
        setLiked(prev => ({ ...prev, [id]: !prev[id] }));
      } catch (err) {
        console.error('Error updating favorites:', err);
      }
    } else {
      const guestFav = JSON.parse(localStorage.getItem('guestFavorites')) || [];
      let updatedFav;
      if (!liked[id]) {
        updatedFav = [...guestFav, id];
      } else {
        updatedFav = guestFav.filter(favId => favId !== id);
      }
      localStorage.setItem('guestFavorites', JSON.stringify(updatedFav));
      setLiked(prev => ({ ...prev, [id]: !prev[id] }));
    }
  };

  const styles = {
    card: (color) => ({
      position: "relative",
      backgroundColor: "#111",
      width: "100%",
      padding: "20px",
      borderRadius: "12px",
      color: "#fff",
      boxShadow: `0 0 20px ${color}`,
      transition: "transform 0.3s",
      cursor: "pointer",
      minHeight: "550px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }),
    badge: (color) => ({
      position: "absolute",
      top: "10px",
      left: "10px",
      backgroundColor: "#000",
      border: `2px solid ${color}`,
      padding: "8px",
      borderRadius: "5px",
      fontSize: "12px",
      color: color,
      fontWeight: 600,
    }),
  };

  return (
    <section style={{ padding: '60px 20px', background: '#0a0a0a' }}>
      <div style={{ textAlign: 'center', marginBottom: '10px' }}>
        <span style={{ color: '#7d993e', fontSize: '18px', fontWeight: 600 }}>
          Your Future Home Awaits!
        </span>
        <h2 style={{ fontSize: '36px', fontWeight: 'bold', margin: '10px 0', color: 'white' }}>
          Find Your Dream Here
        </h2>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '30px', color: 'white' }}>
        <h5 style={{ fontSize: '16px' }}>
          <span style={{ fontWeight: 'bold' }}>Showing 1–{properties.length}</span> of 3k+ properties
        </h5>
        <div style={{ display: 'flex', gap: '10px' }}>
          <Link to="/filter" style={{
            background: '#82c43c',
            padding: '8px 12px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            textDecoration: 'none'
          }}>
            <VscSettings size={20} color="#fff" />
          </Link>
          <Link to="/favourites" style={{
            background: '#f44336',
            padding: '8px 12px',
            borderRadius: '8px',
            color: 'white',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            textDecoration: 'none'
          }}>
            Favorites
          </Link>
        </div>
      </div>

      <Swiper
        spaceBetween={30}
        autoplay={{ delay: 4000, disableOnInteraction: false }}
        breakpoints={{
          600: { slidesPerView: 1 },
          900: { slidesPerView: 2 },
          1300: { slidesPerView: 3 },
          1500: { slidesPerView: 4 },
        }}
        modules={[Autoplay]}
      >
        {properties.map((property) => (
          <SwiperSlide key={property._id}>
            <div style={styles.card('#83b735')}>
              <div style={{ position: 'relative' }}>
                <Link to={`/property/${property._id}`}>
                  <img
                    src={`http://localhost:5500${property.image}`}
                    alt={property.title}
                    style={{ width: '100%', height: '220px', objectFit: 'cover', borderRadius: '8px' }}
                  />
                </Link>
                <div style={styles.badge('#83b735')}>{property.location}</div>

                <FaHeart
                  onClick={() => toggleLike(property._id)}
                  style={{
                    position: 'absolute',
                    top: 12,
                    right: 12,
                    color: liked[property._id] ? 'red' : '#fff',
                    background: 'rgba(0,0,0,0.3)',
                    padding: '6px',
                    borderRadius: '50%',
                    cursor: 'pointer'
                  }}
                />
              </div>

              <div style={{ marginTop: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <h3 style={{ fontSize: '18px', fontWeight: 700 }}>{property.name}</h3>
                  <span style={{ fontWeight: 'bold', color: '#83b735', fontSize: '16px' }}>${property.price}</span>
                </div>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', fontSize: '14px', color: '#ccc' }}>
                  <span><FaBed /> {property.beds}</span>
                  <span><FaBath /> {property.baths}</span>
                  <span><MdMeetingRoom /> {property.rooms}</span>
                  <span><FaCar /> {property.parking}</span>
                  <span><FaArrowsAltH /> {property.size}</span>
                  <span><FaStar style={{ color: 'gold' }} /> {property.rating}</span>
                </div>

                <p style={{ fontSize: '16px', color: '#ddd', lineHeight: '1.5', marginTop: '10px' }}>
                  {property.details?.length > 200
                    ? property.details.slice(0, 200) + '...'
                    : property.details}
                </p>

                <Link to={`/property/${property._id}`} style={{
                  display: 'inline-block',
                  backgroundColor: '#83b735',
                  color: '#fff',
                  padding: '10px 20px',
                  borderRadius: '8px',
                  textDecoration: 'none',
                  fontWeight: 600,
                  marginTop: '10px'
                }}>
                  Book Now
                </Link>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
};

export default Properties;


