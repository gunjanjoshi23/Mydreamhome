import React from 'react';

const Footer = () => {
  const footerWrapperStyle = {
    fontFamily: 'sans-serif',
    backgroundColor: '#fdfdf6',
    color: '#333',
  };

  const topBannerStyle = {
    background: 'linear-gradient(to right, #f1f4dc, #fdfdf6)',
    padding: '30px 40px',
  };

  const topBannerText = {
    fontSize: '1.2em',
    fontWeight: 'bold',
    marginBottom: '10px',
  };

  const bottomFooterStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '80px 40px 20px',
    flexWrap: 'wrap',
    gap: '200px'
  };

  const columnStyle = {
    flex: '1',
    minWidth: '200px',
    marginBottom: '30px',
  };

  const contactInfo = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '16px',
    fontWeight: '500',
    marginBottom: '50px'

  };

  const logoStyle = {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '15px',
  };

  const logoIcon = {
    fontSize: '2em',
    marginRight: '10px',
  };

  const sectionTitle = {
    fontWeight: 'bold',
    marginBottom: '15px',
  };

  const linkStyle = {
    display: 'block',
    marginBottom: '8px',
    color: '#555',
    textDecoration: 'none',
    fontSize: '0.95em',
  };

  const contactRowStyle = {
    display: 'flex',
    justifyContent: 'center',
    gap: '40px',
    marginTop: '20px',
    flexWrap: 'wrap',
    marginLeft: '600px',
  };

  const iconStyle = {
    marginRight: '10px',
    fontSize: '1.2em',
  };

  const copyrightStyle = {
    backgroundColor: '#f1f4dc',
    textAlign: 'left',
    padding: '5px 10px',
    fontSize: '0.85em',
    color: '#777',
    marginTop: '20px',
  };


  return (
    <div style={footerWrapperStyle}>
      <div style={footerWrapperStyle}>
        <div style={topBannerStyle}>
          <div style={topBannerText}>We are always here to help</div>
          <p style={{ fontSize: '16px', color: '#4B5563', maxWidth: '600px' }}>
            Whether you're buying, selling, or just exploring options, our team is ready to guide you every step of the way.
          </p>
          {/* Updated Contact Info (all in one row) */}
          <div style={contactRowStyle}>
            <div style={contactInfo}><span style={iconStyle}>📍</span> <b>Location:</b> 123, Avenue, Cl</div>
            <div style={contactInfo}><span style={iconStyle}>📞</span> <b>Phone:</b> +0123456789</div>
            <div style={contactInfo}><span style={iconStyle}>✉️</span> <b>Email:</b> my@dreamhomes.com</div>
          </div>
        </div>
      </div>


      <div style={bottomFooterStyle}>
        {/* Left Column */}
        <div style={columnStyle}>
          <div style={logoStyle}>
            <span style={logoIcon}>🏠</span>
            <div>
              <strong>My Dream Homes</strong>
            </div>
          </div>
          <p>Discover your perfect property with My Dream Homes — where comfort, style, and convenience come together. Browse top listings, explore ideal locations, and make your dream a reality today.</p>
        </div>

        {/* Customer Service */}
        <div style={columnStyle}>
          <div style={sectionTitle}>Customer Service</div>
          <a href="#" style={linkStyle}>Help center</a>
          <a href="#" style={linkStyle}>Payment methods</a>
          <a href="#" style={linkStyle}>Contact</a>
          <a href="#" style={linkStyle}>Shipping status</a>
          <a href="#" style={linkStyle}>Complaints</a>
        </div>

        {/* Legal */}
        <div style={columnStyle}>
          <div style={sectionTitle}>Legal</div>
          <a href="#" style={linkStyle}>Privacy Policy</a>
          <a href="#" style={linkStyle}>Cookie settings</a>
          <a href="#" style={linkStyle}>Terms & conditions</a>
          <a href="#" style={linkStyle}>Cancelation</a>
          <a href="#" style={linkStyle}>Imprint</a>
        </div>

        {/* Others */}
        <div style={columnStyle}>
          <div style={sectionTitle}>Others</div>
          <a href="#" style={linkStyle}>Our teams</a>
          <a href="#" style={linkStyle}>Sustainability</a>
          <a href="#" style={linkStyle}>Press</a>
          <a href="#" style={linkStyle}>Jobs</a>
          <a href="#" style={linkStyle}>Newsletter</a>
        </div>

        {/* Contact Info
        <div style={columnStyle}>
          <div style={contactInfo}>
            <span style={iconStyle}>📍</span>
            <span>123, Avenue, Cl</span>
          </div>
          <div style={contactInfo}>
            <span style={iconStyle}>📞</span>
            <span>+0123456789</span>
          </div>
          <div style={contactInfo}>
            <span style={iconStyle}>✉️</span>
            <span>info@zenhomes.com</span>
          </div>
        </div> */}
      </div>

      <div style={copyrightStyle}>
        <span>2025 My Dream Home</span> <span style={{ float: 'right' }}>All rights reserved</span>
      </div>
    </div>
  );
};

export default Footer;
