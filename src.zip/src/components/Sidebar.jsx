import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";

const Sidebar = () => {
  const location = useLocation();

  const [openMenus, setOpenMenus] = useState({});

  const toggleDropdown = (label) => {
    setOpenMenus((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  const colors = {
    sidebarBg: "#ffffff",
    border: "#eee",
    primary: "#6e5ed2",
    text: "#555",
    hover: "#f0f0f0",
    activeBg: "#f2f0ff",
    activeText: "#6e5ed2",
  };

  const menuItems = [
    { label: "Dashboard", icon: "📊", path: "/admindashboard" },
    {
      label: "Manage Users",
      icon: "👤",
      path: "/admin/users"
    },
{
  label: "Manage Listings",
  icon: "🏠",
  path: "/admin/listings",
  children: [
    { label: "Add Listing", path: "/admin/listings/add" },
    { label: "Manage Listings", path: "/admin/listings/manage" }
  ]
},

    {
      label: "Manage Bookings",
      icon: "📅",
      path: "/admin/bookings",
          },
    {
      label: "Manage Testimonials",
      icon: "💬",
      path: "/admin/testimonials"
    },
    {
      label: "Contact Queries",
      icon: "📥",
      path: "/admin/queries",
      children: [
        { label: "View Queries", path: "/admin/queries/view" },
        { label: "Mark Resolved/Unresolved", path: "/admin/queries/mark" }
      ]
    },
    { label: "Logout", icon: "🚪", path: "/" }
  ];

  return (
    <div
      style={{
        width: "250px",
        backgroundColor:"black",
        padding: "25px 20px",
        borderRight: `1px solid ${colors.border}`,
        display: "flex",
        flexDirection: "column",
        gap: "10px",
        minHeight: "100vh"
      }}
    >
      <h2
        style={{
          color: colors.primary,
          marginBottom: "20px",
          fontSize: "22px"
        }}
      >
        Admin Panel
      </h2>

      {menuItems.map((item, idx) => {
        const isActive = location.pathname === item.path;
        const hasChildren = item.children && item.children.length > 0;

        return (
          <div key={idx}>
            <div
              onClick={() => hasChildren && toggleDropdown(item.label)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px 15px",
                borderRadius: "8px",
                backgroundColor: isActive ? colors.activeBg : "transparent",
                color: isActive ? colors.activeText : colors.text,
                cursor: "pointer",
                transition: "background 0.3s"
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = colors.hover)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = isActive
                  ? colors.activeBg
                  : "transparent")
              }
            >
              <span style={{ fontSize: "18px" }}>{item.icon}</span>
              {hasChildren ? (
                <span style={{ fontSize: "16px", flex: 1 }}>{item.label}</span>
              ) : (
                <Link
                  to={item.path}
                  style={{
                    fontSize: "16px",
                    color: isActive ? colors.activeText : colors.text,
                    textDecoration: "none",
                    flex: 1
                  }}
                >
                  {item.label}
                </Link>
              )}
              {hasChildren && (
                <span style={{ fontSize: "12px" }}>
                  {openMenus[item.label] ? "▲" : "▼"}
                </span>
              )}
            </div>

            {/* Render child links if dropdown is open */}
            {hasChildren && openMenus[item.label] && (
              <div style={{ marginLeft: "25px", marginTop: "5px" }}>
                {item.children.map((child, i) => (
                  <Link
                    key={i}
                    to={child.path}
                    style={{
                      display: "block",
                      padding: "6px 0",
                      fontSize: "14px",
                      color:
                        location.pathname === child.path
                          ? colors.activeText
                          : colors.text,
                      textDecoration: "none"
                    }}
                  >
                    {child.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default Sidebar;
