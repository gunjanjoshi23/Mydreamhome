import React, { useEffect, useState } from 'react';
import Sidebar from './Sidebar';

function ContactQueries() {
  const [queries, setQueries] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5500/api/contact-queries')
      .then(res => res.json())
      .then(data => setQueries(data))
      .catch(err => console.error('Failed to fetch:', err));
  }, []);

  return (
    <div style={container}>
      <Sidebar />
      <div style={content}>
        <h2 style={title}>Contact Queries</h2>
        {queries.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'white' }}>No contact queries found.</p>
        ) : (
          <div style={cardContainer}>
            {queries.map((q) => (
              <div key={q._id} style={card}>
                <p><strong>Name:</strong> {q.name}</p>
                <p><strong>Email:</strong> {q.email}</p>
                <p><strong>Phone:</strong> {q.phone || 'N/A'}</p>
                <p><strong>Message:</strong> {q.message}</p>
                <p style={timestamp}>
                  Submitted on: {new Date(q.createdAt).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Styled CSS
const container = {
  display: 'flex',
  minHeight: '100vh',
  backgroundImage: `url('https://i.pinimg.com/originals/c4/ad/f9/c4adf98450d7b72a0c71efd9cd10fd4f.jpg')`,
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  color: 'white'
};

const content = {
  flex: 1,
  padding: '40px',
  fontFamily: 'Arial, sans-serif',
};

const title = {
  textAlign: 'center',
  color: 'white',
  marginBottom: '30px',
  fontSize: '30px',
  fontWeight: 'bold'
};

const cardContainer = {
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'space-between',
  gap: '20px',
  padding: '20px',
};

const card = {
  flex: '0 0 30%',
  backgroundColor: '#30e3ca',
  padding: '20px',
  borderRadius: '10px',
  boxShadow: '0 4px 10px rgba(0,0,0,0.3)',
  color: '#0d1b2a',
  boxSizing: 'border-box'
};

const timestamp = {
  fontSize: '12px',
  color: '#555',
  marginTop: '5px'
};

export default ContactQueries;
