import React from 'react';

const HeroSection = ({ isMobile }) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: isMobile ? 'column' : 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: '4rem',
        gap: '2rem',
        backgroundColor: '#008274',
        paddingTop: '80px',
        paddingLeft: '50px',
        marginTop: '100px'
      }}
    >
      <div style={{ maxWidth: '600px' }}>
        <h1 style={{ fontSize: isMobile ? '2.2rem' : '3.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          Discover Your Dream<br />Property Today
        </h1>
        <p style={{ color: '#fff', marginBottom: '1rem', fontSize: isMobile ? '0.9rem' : '1rem' }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', marginBottom: '6rem' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <button style={{ backgroundColor: '#fff', border: '1px solid #ccc', fontWeight: 'bold', padding: '0.5rem 1rem', borderRadius: '8px', cursor: 'pointer' }}>
              10% OFF On All Properties
            </button>
            <button style={{ backgroundColor: 'black', color: 'white', padding: '0.5rem 1rem', borderRadius: '8px', cursor: 'pointer' }}>
              Explore
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {['/OIP (1).jpeg', '/vector-users-icon.jpg', '/user-icon-7.jpg', '/OIP.jpeg', '/vector-users-icon.jpg'].map((img, i) => (
                <img key={i} src={img} alt="user" style={{ width: '40px', height: '40px', borderRadius: '50%', marginLeft: i !== 0 ? '-10px' : '0', border: '2px solid white', objectFit: 'cover' }} />
              ))}
              <div style={{ width: '40px', height: '40px', backgroundColor: '#ccc', borderRadius: '50%', marginLeft: '-10px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                210K+
              </div>
            </div>
            <div style={{ lineHeight: '1.4' }}>
              <p style={{ fontWeight: 'bold', fontSize: isMobile ? '0.95rem' : '1.1rem', margin: 22, marginLeft: '0px', padding: 10, paddingRight: 0 }}>
                People successfully got their dream homes
              </p>
              <p style={{ margin: 0, color: '#444', fontSize: isMobile ? '0.85rem' : '1rem' }}>
                ⭐⭐⭐⭐⭐
              </p>
              <p style={{ margin: 0, color: '#444', fontSize: isMobile ? '0.85rem' : '1rem' }}>
                <b>127k Excellent Reviews</b>
              </p>

            </div>
          </div>
        </div>
      </div>

      <img
        src="https://is1-3.housingcdn.com/4f2250e8/c8072369f0f7294ed7e8d1c8efeeb76f/v0/fs/my_home_dreams-nagondanahalli-bengaluru-my_home_infra_project.jpeg"
        alt="house"
        style={{
          width: isMobile ? '100%' : '45%',
          borderRadius: '1rem',
          objectFit: 'cover',
        }}
      />
    </div>
  );
};

export default HeroSection;
