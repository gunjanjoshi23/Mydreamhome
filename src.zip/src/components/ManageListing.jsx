import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Sidebar from './Sidebar'; // Ensure Sidebar exists and is correctly styled
import { Link } from 'react-router-dom';


const ManageListing = () => {
    const [listings, setListings] = useState([]);

    useEffect(() => {
        fetchListings();
    }, []);

    const fetchListings = async () => {
        try {
            const res = await axios.get('http://localhost:5500/api/listings');
            setListings(res.data);
        } catch (err) {
            console.error('Error fetching listings:', err);
        }
    };

    const handleDelete = async (id) => {
        const confirmDelete = window.confirm("Are you sure you want to delete this listing?");
        if (!confirmDelete) return;

        try {
            await axios.delete(`http://localhost:5500/api/listings/${id}`);
            setListings(listings.filter(listing => listing._id !== id));
            alert("Listing deleted successfully!");
        } catch (err) {
            console.error('Error deleting listing:', err);
            alert("Failed to delete the listing. Please try again.");
        }
    };


    return (
        <div style={{ display: 'flex', minHeight: '100vh',backgroundColor:'#b1ddf1' }}>
            <Sidebar />
            <div style={{ flex: 1, padding: '20px', backgroundColor: '#b1ddf1', fontFamily: 'Arial' }}>
                <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Manage Listings</h2>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
                    {listings.length === 0 ? (
                        <p style={{ textAlign: 'center' }}>No listings available.</p>
                    ) : (
                        listings.map((listing) => (
                            <div key={listing._id} style={{
                                border: '1px solid #ccc',
                                borderRadius: '10px',
                                padding: '15px',
                                width: '300px',
                                backgroundColor: '#fff',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                            }}>
                                <div style={{ position: 'relative' }}>
                                    <img
                                        src={`http://localhost:5500${listing.image}`}
                                        alt={listing.title}
                                        style={{
                                            width: '100%',
                                            height: '180px',
                                            objectFit: 'cover',
                                            borderRadius: '10px',
                                            objectFit: 'cover'
                                        }}
                                    />
                                </div>
                                <h3 style={{ margin: '10px 0 5px' }}>{listing.name}</h3>
                                <p><strong>Location:</strong> {listing.location}</p>
                                <p><strong>Price:</strong> ${listing.price}</p>
                                <p><strong>Rooms:</strong> {listing.rooms}</p>
                                <p><strong>Parking:</strong> {listing.parking}</p>
                                <p><strong>Beds:</strong> {listing.beds}</p>
                                <p><strong>Baths:</strong> {listing.baths}</p>
                                <p style={{ fontSize: '16px', color: 'black', lineHeight: '1.5', marginTop: '10px' }}>
                                    {listing.details?.length > 200
                                        ? listing.details.slice(0, 200) + '...'
                                        : listing.details}
                                </p>
                                <button
                                    onClick={() => handleDelete(listing._id)}
                                    style={{
                                        backgroundColor: '#ff4d4f',
                                        color: '#fff',
                                        border: 'none',
                                        padding: '8px 12px',
                                        borderRadius: '5px',
                                        cursor: 'pointer',
                                        marginTop: '10px',
                                        width: '100%'
                                    }}
                                >
                                    Delete
                                </button>
                                <Link
                                    to={`/admin/edit-listing/${listing._id}`}
                                    style={{
                                        display: 'inline-block',
                                        textAlign: 'center',
                                        backgroundColor: '#1890ff',
                                        color: '#fff',
                                        textDecoration: 'none',
                                        padding: '8px 12px',
                                        borderRadius: '5px',
                                        marginTop: '10px',
                                        width: '90%'
                                    }}
                                >
                                    Edit
                                </Link>


                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

export default ManageListing;



