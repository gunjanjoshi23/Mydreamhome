// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';

// const Header = () => {
//   const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
//   const [hovered, setHovered] = useState('');
//   const [user, setUser] = useState(null);
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const handleResize = () => setIsMobile(window.innerWidth < 768);
//     window.addEventListener('resize', handleResize);
//     return () => window.removeEventListener('resize', handleResize);
//   }, []);

//   useEffect(() => {
//     const storedUser = localStorage.getItem('user');
//     if (storedUser) {
//       setUser(JSON.parse(storedUser));
//     }
//   }, []);

//   const handleLogout = () => {
//     localStorage.removeItem('user');
//     setUser(null);
//     navigate('/');
//   };

//   const isLoggedIn = !!user;
//   const isAdmin = user?.isAdmin || false;

//   const styles = {
//     header: {
//       backgroundColor: 'olive',
//       position: 'fixed',
//       top: 0,
//       left: 0,
//       right: 0,
//       width: '100%',
//       zIndex: 1000,
//       padding: '0 4rem',
//     },
//     headerContainer: {
//       display: 'flex',
//       flexDirection: isMobile ? 'column' : 'row',
//       justifyContent: 'space-between',
//       alignItems: 'center',
//       padding: isMobile ? '1rem' : '1.5rem 0',
//       gap: isMobile ? '1rem' : 0,
//     },
//     logo: {
//       display: 'flex',
//       alignItems: 'center',
//       gap: '0.5rem',
//       justifyContent: isMobile ? 'center' : 'flex-start',
//     },
//     logoImg: {
//       height: isMobile ? '50px' : '70px',
//     },
//     logoText: {
//       fontSize: isMobile ? '1.2rem' : '1.5rem',
//     },
//     navLinks: {
//       display: 'flex',
//       flexDirection: isMobile ? 'column' : 'row',
//       alignItems: 'center',
//       gap: isMobile ? '0.8rem' : '2rem',
//       marginTop: isMobile ? '1rem' : 0,
//     },
//     navLink: {
//       textDecoration: 'none',
//       color: 'black',
//       padding: '0.3rem 0',
//       fontSize: isMobile ? '0.95rem' : '1rem',
//       borderBottom: '2px solid transparent',
//       transition: 'border-bottom 0.3s ease',
//     },
//     navLinkHovered: {
//       textDecoration: 'none',
//       color: 'black',
//       padding: '0.3rem 0',
//       fontSize: isMobile ? '0.95rem' : '1rem',
//       borderBottom: '2px solid black',
//       transition: 'border-bottom 0.3s ease',
//     },
//     buttonsContainer: {
//       display: 'flex',
//       flexDirection: isMobile ? 'column' : 'row',
//       gap: isMobile ? '0.8rem' : '1rem',
//       marginTop: isMobile ? '1rem' : 0,
//       alignItems: 'center',
//       marginRight: isMobile ? '1rem' : 80,
//       position: 'relative',
//     },
//     button: {
//       backgroundColor: 'black',
//       color: 'white',
//       padding: '0.5rem 1rem',
//       borderRadius: '8px',
//       cursor: 'pointer',
//       width: isMobile ? '100%' : 'auto',
//       border: 'none',
//       fontSize: '1rem',
//     },
//     link: {
//       textDecoration: 'none',
//     },
//     dropdown: {
//       position: 'absolute',
//       top: '120%',
//       right: 0,
//       backgroundColor: 'white',
//       border: '1px solid #ccc',
//       borderRadius: '6px',
//       boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
//       padding: '0.5rem 1rem',
//       zIndex: 999,
//       minWidth: '150px',
//     },
//     dropdownItem: {
//       padding: '0.4rem 0',
//       cursor: 'pointer',
//       fontSize: '0.95rem',
//       borderBottom: '1px solid #eee',
//     },
//   };

//   return (
//     <div style={styles.header}>
//       <div style={styles.headerContainer}>
//         {/* Logo */}
//         <div style={styles.logo}>
//           <img src="/home.png" alt="Homes" style={styles.logoImg} />
//           <strong style={styles.logoText}>My Dream Home</strong>
//         </div>

//         {/* Nav Links */}
//         <div style={styles.navLinks}>
//           {['Home', 'Listing', 'Contact', 'Add Property'].map((item, idx) => {
//             const path = item === 'Home' ? '/' : `/${item.toLowerCase().replace(/\s/g, '-')}`;
//             return (
//               <Link
//                 key={idx}
//                 to={path}
//                 style={hovered === item ? styles.navLinkHovered : styles.navLink}
//                 onMouseEnter={() => setHovered(item)}
//                 onMouseLeave={() => setHovered('')}
//               >
//                 {item}
//               </Link>
//             );
//           })}
//         </div>

//         {/* Buttons / User Dropdown */}
//         <div style={styles.buttonsContainer}>
//           {isLoggedIn ? (
//             <>
//               <button
//                 onClick={() => setDropdownOpen(!dropdownOpen)}
//                 style={styles.button}
//                 aria-haspopup="true"
//                 aria-expanded={dropdownOpen}
//               >
//                 {user.name} ▼
//               </button>
//               {dropdownOpen && (
//                 <div style={styles.dropdown}>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/profile'); }}>
//                     Profile
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/favourites'); }}>
//                     Favourites
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/bookings'); }}>
//                     Bookings
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/my-testimonial'); }}>
//                     My Testimonials
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/post-testimonial'); }}>
//                     Post Testimonials
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); handleLogout(); }}>
//                     Logout
//                   </div>
//                 </div>
//               )}
//             </>
//           ) : (
//             <>
//               <Link to="/admin" style={styles.link}>
//                 <button style={styles.button}>Admin Login</button>
//               </Link>
//               <Link to="/login" style={styles.link}>
//                 <button style={styles.button}>Log In</button>
//               </Link>
//             </>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Header; 


// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';

// const Header = () => {
//   const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
//   const [hovered, setHovered] = useState('');
//   const [user, setUser] = useState(null);
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const handleResize = () => setIsMobile(window.innerWidth < 768);
//     window.addEventListener('resize', handleResize);
//     return () => window.removeEventListener('resize', handleResize);
//   }, []);

//   useEffect(() => {
//     const storedUser = localStorage.getItem('user');
//     if (storedUser) {
//       setUser(JSON.parse(storedUser));
//     }
//   }, []);

//   const handleLogout = () => {
//     localStorage.removeItem('user');
//     setUser(null);
//     navigate('/');
//   };

//   const isLoggedIn = !!user;

//   const styles = {
//     header: {
//       backgroundColor: 'olive',
//       position: 'fixed',
//       top: 0,
//       left: 0,
//       right: 0,
//       width: '100%',
//       zIndex: 1000,
//       padding: '0.5rem 1rem',
//     },
//     headerContainer: {
//       display: 'flex',
//       alignItems: 'center',
//       justifyContent: 'space-between',
//       flexWrap: 'wrap',
//     },
//     leftGroup: {
//       display: 'flex',
//       gap: '1rem',
//       alignItems: 'center',
//       flexWrap: 'wrap',
//     },
//     logo: {
//       display: 'flex',
//       alignItems: 'center',
//       justifyContent: 'center',
//       flex: 1,
//       paddingRight:'500px'
//     },
//     logoImg: {
//       height: isMobile ? '50px' : '70px',
//       marginRight: '1rem',
//     },
//     logoText: {
//       fontSize: isMobile ? '1.2rem' : '1.8rem',
//       fontWeight: 'bold',
//       color: 'black',

//     },
//     navLink: {
//       textDecoration: 'none',
//       color: 'black',
//       fontSize: '1rem',
//       borderBottom: '2px solid transparent',
//       transition: 'border-bottom 0.3s ease',
//     },
//     navLinkHovered: {
//       textDecoration: 'none',
//       color: 'black',
//       fontSize: '1rem',
//       borderBottom: '2px solid black',
//       transition: 'border-bottom 0.3s ease',
//     },
//     button: {
//       backgroundColor: 'black',
//       color: 'white',
//       padding: '0.5rem 1rem',
//       borderRadius: '8px',
//       cursor: 'pointer',
//       border: 'none',
//       fontSize: '1rem',
//     },
//     link: {
//       textDecoration: 'none',
//     },
//     dropdownWrapper: {
//       position: 'relative',
//     },
//     dropdown: {
//       position: 'absolute',
//       top: '100%',
//       right: 0,
//       backgroundColor: 'white',
//       border: '1px solid #ccc',
//       borderRadius: '6px',
//       boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
//       padding: '0.5rem 1rem',
//       zIndex: 999,
//       minWidth: '150px',
//       marginTop: '0.5rem',
//     },
//     dropdownItem: {
//       padding: '0.4rem 0',
//       cursor: 'pointer',
//       fontSize: '0.95rem',
//       borderBottom: '1px solid #eee',
//     },
//     rightGroup: {
//       display: 'flex',
//       alignItems: 'center',
//       gap: '1rem',
//     },
//   };

//   return (
//     <div style={styles.header}>
//       <div style={styles.headerContainer}>
//         <div style={styles.leftGroup}>
//           {['Home', 'Listing', 'Contact', 'Add Property'].map((item, idx) => {
//             const path = item === 'Home' ? '/' : `/${item.toLowerCase().replace(/\s/g, '-')}`;
//             return (
//               <Link
//                 key={idx}
//                 to={path}
//                 style={hovered === item ? styles.navLinkHovered : styles.navLink}
//                 onMouseEnter={() => setHovered(item)}
//                 onMouseLeave={() => setHovered('')}
//               >
//                 {item}
//               </Link>
//             );
//           })}
//           {!isLoggedIn && (
//             <>
//               <Link to="/admin" style={styles.link}>
//                 <button style={styles.button}>Admin Login</button>
//               </Link>
//               <Link to="/login" style={styles.link}>
//                 <button style={styles.button}>Log In</button>
//               </Link>
//             </>
//           )}
//         </div>

//         <div style={styles.logo}>
//           <img src="/home.png" alt="Homes" style={styles.logoImg} />
//           <strong style={styles.logoText}>My Dream Home</strong>
//         </div>

//         {isLoggedIn && (
//           <div style={styles.rightGroup}>
//             <div style={styles.dropdownWrapper}>
//               <button
//                 onClick={() => setDropdownOpen(!dropdownOpen)}
//                 style={styles.button}
//               >
//                 {user.name} ▼
//               </button>
//               {dropdownOpen && (
//                 <div style={styles.dropdown}>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/profile'); }}>
//                     Profile
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/favourites'); }}>
//                     Favourites
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/bookings'); }}>
//                     Bookings
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/my-testimonial'); }}>
//                     My Testimonials
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/post-testimonial'); }}>
//                     Post Testimonials
//                   </div>
//                   <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); handleLogout(); }}>
//                     Logout
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Header;

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Header = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [hovered, setHovered] = useState('');
  const [user, setUser] = useState(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    navigate('/');
  };

  const isLoggedIn = !!user;

  const styles = {
    header: {
      backgroundColor: '#f4cbbf',
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      width: '100%',
      zIndex: 1000,
      padding: '0.5rem 1rem',
    },
    headerContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    leftGroup: {
      display: 'flex',
      gap: '1rem',
      alignItems: 'center',
      flexWrap: 'wrap',

    },
    logo: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 1,
    },
    logoImg: {
      height: isMobile ? '50px' : '70px',
      marginRight: '1rem',
    },
    logoText: {
      fontSize: isMobile ? '1.2rem' : '1.8rem',
      fontWeight: 'bold',
      color: 'black',
    },
    navLink: {
      textDecoration: 'none',
      color: 'black',
  fontSize: '1.2rem', // ← same increase here
      borderBottom: '2px solid transparent',
      transition: 'border-bottom 0.3s ease',
    },
    navLinkHovered: {
      textDecoration: 'none',
      color: 'black',
        fontSize: '1.2rem', // ← same increase here

      fontSize: '1rem',
      borderBottom: '2px solid black',
      transition: 'border-bottom 0.3s ease',
    },
    button: {
      backgroundColor: 'black',
      color: 'white',
      padding: '1rem ',
      borderRadius: '8px',
      cursor: 'pointer',
      border: 'none',
      fontSize: '1rem',
      marginRight: '50px'

    },
    link: {
      textDecoration: 'none',

    },
    dropdownWrapper: {
      position: 'relative',
    },
    dropdown: {
      position: 'absolute',
      top: '100%',
      right: 0,
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '6px',
      boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
      padding: '0.5rem 1rem',
      zIndex: 999,
      minWidth: '150px',
      marginTop: '0.5rem',
    },
    dropdownItem: {
      padding: '0.4rem 0',
      cursor: 'pointer',
      fontSize: '0.95rem',
      borderBottom: '1px solid #eee',
    },
    rightGroup: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem',
    },
  };

  return (
    <div style={styles.header}>
      <div style={styles.headerContainer}>
        <div style={styles.leftGroup}>
          {['Home', 'Listing', 'Contact', ''].map((item, idx) => {
            const path = item === 'Home' ? '/' : `/${item.toLowerCase().replace(/\s/g, '-')}`;
            return (
              <Link
                key={idx}
                to={path}
                style={hovered === item ? styles.navLinkHovered : styles.navLink}
                onMouseEnter={() => setHovered(item)}
                onMouseLeave={() => setHovered('')}
              >
                {item}
              </Link>
            );
          })}
        </div>

        <div style={styles.logo}>
          <img src="/home.png" alt="Homes" style={styles.logoImg} />
          <strong style={styles.logoText}>My Dream Home</strong>
        </div>

        <div style={styles.rightGroup}>
          {!isLoggedIn ? (
            <>
              <Link to="/admin" style={styles.link}>
                <button style={styles.button}>Admin Login</button>
              </Link>
              <Link to="/login" style={styles.link}>
                <button style={styles.button}>Log In</button>
              </Link>
            </>
          ) : (
            <div style={styles.dropdownWrapper}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                style={styles.button}
              >
                {user.name} ▼
              </button>
              {dropdownOpen && (
                <div style={styles.dropdown}>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/profile'); }}>
                    Profile
                  </div>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/favourites'); }}>
                    Favourites
                  </div>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/my-bookings'); }}>
                    Bookings
                  </div>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/my-testimonial'); }}>
                    My Testimonials
                  </div>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); navigate('/post-testimonial'); }}>
                    Post Testimonials
                  </div>
                  <div style={styles.dropdownItem} onClick={() => { setDropdownOpen(false); handleLogout(); }}>
                    Logout
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Header;

