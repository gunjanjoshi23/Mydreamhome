

import React, { useEffect, useState } from 'react';
import Sidebar from './Sidebar'; // Adjust path as needed

const ManageTestimonials = () => {
  const [testimonials, setTestimonials] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5500/api/testimonials')
      .then(res => res.json())
      .then(data => {
        if (data.success) setTestimonials(data.testimonials);
      })
      .catch(err => console.error('Error fetching testimonials:', err));
  }, []);

  const toggleStatus = async (id) => {
    try {
      const testimonial = testimonials.find(t => t._id === id);
      if (!testimonial) return;

      const newStatus = testimonial.status === 'active' ? 'inactive' : 'active';

      const res = await fetch(`http://localhost:5500/api/testimonials/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });

      const data = await res.json();
      if (data.success) {
        setTestimonials(testimonials.map(t => 
          t._id === id ? { ...t, status: newStatus } : t
        ));
      }
    } catch (error) {
      console.error('Error toggling status:', error);
    }
  };

const deleteTestimonial = async (id) => {
  const confirmDelete = window.confirm('Are you sure you want to delete this testimonial?');
  if (!confirmDelete) return; // if user clicks Cancel, exit

  try {
    const res = await fetch(`http://localhost:5500/api/testimonials/${id}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (data.success) {
      setTestimonials(testimonials.filter(t => t._id !== id));
      alert('Testimonial deleted successfully.');
    } else {
      alert('Failed to delete testimonial.');
    }
  } catch (error) {
    console.error('Error deleting testimonial:', error);
    alert('Error deleting testimonial.');
  }
};


  return (
    <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'sans-serif', }}>
      
      {/* Sidebar */}
      <div style={{ width: '250px', backgroundColor: '#2c3e50', color: '#ecf0f1' }}>
        <Sidebar />
      </div>

      {/* Main content */}
      <div style={{ flexGrow: 1, padding: '30px', backgroundColor: '#5b7b7a' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Manage Testimonials</h2>
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
          gap: '20px' 
        }}>
          {testimonials.map(t => (
            <div key={t._id} style={{
              backgroundColor: '#fff',
              padding: '20px',
              borderRadius: '10px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              position: 'relative'
            }}>
              <h3 style={{ marginBottom: '10px', color: '#333' }}>{t.user?.name || 'Anonymous'}</h3>
              <p style={{ fontStyle: 'italic', color: '#555' }}>"{t.testimonial}"</p>
              <p style={{ marginTop: '10px', color: '#999' }}>Rating: {t.rating} ⭐</p>
              <p style={{ marginTop: '5px', color: t.status === 'active' ? 'green' : 'red' }}>
                Status: {t.status}
              </p>
              <div style={{ marginTop: '15px' }}>
                <button 
                  onClick={() => toggleStatus(t._id)} 
                  style={{ marginRight: '10px', padding: '5px 10px', cursor: 'pointer' }}
                >
                  Toggle Status
                </button>
                <button 
                  onClick={() => deleteTestimonial(t._id)} 
                  style={{ padding: '5px 10px', backgroundColor: 'red', color: 'white', cursor: 'pointer' }}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

export default ManageTestimonials;
